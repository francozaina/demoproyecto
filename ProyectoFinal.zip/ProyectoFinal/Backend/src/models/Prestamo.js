export class Prestamo{
    id;
    estado;
    FechaSolicitud;
    FechaAceptado;
    FechaEntregado;
    FechaDevuelto;
    fk_Objeto;
    fk_Usuario;
    fk_Admin;
}